This repos contains a Project, Which use a model to track and monitor the activity of a person using AI.
